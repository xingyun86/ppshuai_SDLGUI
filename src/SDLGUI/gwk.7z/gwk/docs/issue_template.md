
Issue:

- Operating System (name & version):
- Compiler (name & version):
- Target renderer:
- cmake command-line used:
