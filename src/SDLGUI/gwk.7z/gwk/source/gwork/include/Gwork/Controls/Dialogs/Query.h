/*
 *  Gwork
 *  Copyright (c) 2010 Facepunch Studios
 *  Copyright (c) 2013-2018 Billy Quith
 *  See license in Gwork.h
 */

#pragma once
#ifndef GWK_CONTROLS_DIALOGS_QUERY_H
#define GWK_CONTROLS_DIALOGS_QUERY_H

#include <Gwork/Gwork.h>

namespace Gwk
{
    namespace Dialogs
    {
        //
        //! @todo Add YesNo, Ok etc dialogs.
        //
    }
}

#endif // ifndef GWK_CONTROLS_DIALOGS_QUERY_H
