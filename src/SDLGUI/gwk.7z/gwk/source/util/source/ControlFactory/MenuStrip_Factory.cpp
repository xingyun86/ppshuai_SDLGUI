
#include <Gwork/Util/ControlFactory.h>
#include <Gwork/Controls.h>

namespace Gwk
{
//    namespace ControlFactory
//    {
//        class MenuStrip_Factory : public Gwk::ControlFactory::Base
//        {
//        public:
//
//            GWK_CONTROL_FACTORY_FOR(MenuStrip, Base)
//            {
//            }
//
//            Gwk::Controls::Base* CreateInstance(Gwk::Controls::Base* parent) override
//            {
//                Gwk::Controls::MenuStrip* control = new Gwk::Controls::MenuStrip(parent);
//                return control;
//            }
//
//        };
//
//
//        GWK_CONTROL_FACTORY(MenuStrip_Factory);
//
//    }
}
