
#include <Gwork/Util/ControlFactory.h>
#include <Gwork/Controls.h>

namespace Gwk
{
//    namespace ControlFactory
//    {
//        class TextBox_Factory : public Gwk::ControlFactory::Base
//        {
//        public:
//
//            GWK_CONTROL_FACTORY_FOR(TextBox, Label)
//            {
//            }
//
//            Gwk::Controls::Base* CreateInstance(Gwk::Controls::Base* parent) override
//            {
//                Gwk::Controls::TextBox* control = new Gwk::Controls::TextBox(parent);
//                control->SetSize(100, 20);
//                control->SetText("");
//                return control;
//            }
//
//        };
//
//
//        class TextBoxMultiline_Factory : public Gwk::ControlFactory::Base
//        {
//        public:
//
//            GWK_CONTROL_FACTORY_FOR(TextBoxMultiline, TextBox)
//            {
//            }
//
//            Gwk::Controls::Base* CreateInstance(Gwk::Controls::Base* parent) override
//            {
//                Gwk::Controls::TextBoxMultiline* control =
//                    new Gwk::Controls::TextBoxMultiline(parent);
//                control->SetSize(100, 50);
//                control->SetText("");
//                return control;
//            }
//
//        };
//
//
//        GWK_CONTROL_FACTORY(TextBox_Factory);
//        GWK_CONTROL_FACTORY(TextBoxMultiline_Factory);
//
//    }
}
