
#include <Gwork/Util/ControlFactory.h>
#include <Gwork/Controls.h>

namespace Gwk
{
//    namespace ControlFactory
//    {
//        class ListBox_Factory : public Gwk::ControlFactory::Base
//        {
//        public:
//
//            GWK_CONTROL_FACTORY_FOR(ListBox, Base)
//            {
//            }
//
//            Gwk::Controls::Base* CreateInstance(Gwk::Controls::Base* parent) override
//            {
//                Gwk::Controls::ListBox* control = new Gwk::Controls::ListBox(parent);
//                control->SetSize(100, 100);
//                return control;
//            }
//
//        };
//
//
//        GWK_CONTROL_FACTORY(ListBox_Factory);
//
//    }
}
