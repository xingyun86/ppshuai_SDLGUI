/*
 *  Gwork
 *  Copyright (c) 2013-17 Billy Quith
 *  See license in Gwork.h
 */

#define GWK_VERSION ((1)*1000000 + (0)*1000 + (0))
#define GWK_VERSION_STR "1.0.0 Release"
