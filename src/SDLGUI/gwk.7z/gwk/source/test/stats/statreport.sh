#!/usr/bin/env bash

python allocstats.py
open alloc_report.html
