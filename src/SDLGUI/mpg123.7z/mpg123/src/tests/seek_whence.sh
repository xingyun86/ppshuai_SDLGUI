#!/bin/sh
exec src/tests/seek_whence "$srcdir/src/tests/sweep.mp3"
